/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 334:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.dbQuery = exports.dbScan = exports.dbDelete = exports.dbUpdate = exports.dbPut = exports.dbGet = exports.SLOTS_TABLE = exports.CLASSES_TABLE = exports.BOOKINGS_TABLE = exports.USERS_TABLE = exports.dynamodb = void 0;
const client_dynamodb_1 = __webpack_require__(929);
const lib_dynamodb_1 = __webpack_require__(515);
const client = new client_dynamodb_1.DynamoDBClient({ region: 'us-east-1' });
exports.dynamodb = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
exports.USERS_TABLE = process.env.USERS_TABLE;
exports.BOOKINGS_TABLE = process.env.BOOKINGS_TABLE;
exports.CLASSES_TABLE = process.env.CLASSES_TABLE;
exports.SLOTS_TABLE = process.env.SLOTS_TABLE;
const dbGet = async (tableName, key) => {
    const command = new lib_dynamodb_1.GetCommand({
        TableName: tableName,
        Key: key
    });
    const response = await exports.dynamodb.send(command);
    return response.Item;
};
exports.dbGet = dbGet;
const dbPut = async (tableName, item) => {
    const command = new lib_dynamodb_1.PutCommand({
        TableName: tableName,
        Item: item
    });
    return await exports.dynamodb.send(command);
};
exports.dbPut = dbPut;
const dbUpdate = async (tableName, key, updateExpression, expressionAttributeValues, expressionAttributeNames) => {
    const command = new lib_dynamodb_1.UpdateCommand({
        TableName: tableName,
        Key: key,
        UpdateExpression: updateExpression,
        ExpressionAttributeValues: expressionAttributeValues,
        ExpressionAttributeNames: expressionAttributeNames,
        ReturnValues: 'ALL_NEW'
    });
    const response = await exports.dynamodb.send(command);
    return response.Attributes;
};
exports.dbUpdate = dbUpdate;
const dbDelete = async (tableName, key) => {
    const command = new lib_dynamodb_1.DeleteCommand({
        TableName: tableName,
        Key: key
    });
    return await exports.dynamodb.send(command);
};
exports.dbDelete = dbDelete;
const dbScan = async (tableName, filterExpression, expressionAttributeValues) => {
    const command = new lib_dynamodb_1.ScanCommand({
        TableName: tableName,
        FilterExpression: filterExpression,
        ExpressionAttributeValues: expressionAttributeValues
    });
    const response = await exports.dynamodb.send(command);
    return response.Items || [];
};
exports.dbScan = dbScan;
const dbQuery = async (tableName, indexName, keyConditionExpression, expressionAttributeValues) => {
    const command = new lib_dynamodb_1.QueryCommand({
        TableName: tableName,
        IndexName: indexName,
        KeyConditionExpression: keyConditionExpression,
        ExpressionAttributeValues: expressionAttributeValues
    });
    const response = await exports.dynamodb.send(command);
    return response.Items || [];
};
exports.dbQuery = dbQuery;


/***/ }),

/***/ 342:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.responseHeaders = exports.requireOwner = exports.requireAuth = exports.authenticate = void 0;
const jwt = __importStar(__webpack_require__(829));
const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret';
const authenticate = (event) => {
    try {
        const authHeader = event.headers.Authorization || event.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return null;
        }
        const token = authHeader.substring(7);
        const decoded = jwt.verify(token, JWT_SECRET);
        return {
            userId: decoded.userId,
            email: decoded.email,
            role: decoded.role
        };
    }
    catch (error) {
        console.error('Authentication error:', error);
        return null;
    }
};
exports.authenticate = authenticate;
const requireAuth = (event) => {
    const user = (0, exports.authenticate)(event);
    if (!user) {
        return {
            error: {
                statusCode: 401,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
                },
                body: JSON.stringify({ error: 'Unauthorized' })
            }
        };
    }
    return { user };
};
exports.requireAuth = requireAuth;
const requireOwner = (event) => {
    const authResult = (0, exports.requireAuth)(event);
    if ('error' in authResult) {
        return authResult;
    }
    if (authResult.user.role !== 'owner') {
        return {
            error: {
                statusCode: 403,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
                },
                body: JSON.stringify({ error: 'Forbidden: Owner access required' })
            }
        };
    }
    return authResult;
};
exports.requireOwner = requireOwner;
exports.responseHeaders = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
};


/***/ }),

/***/ 515:
/***/ ((module) => {

module.exports = require("@aws-sdk/lib-dynamodb");

/***/ }),

/***/ 829:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 903:
/***/ ((module) => {

module.exports = require("uuid");

/***/ }),

/***/ 929:
/***/ ((module) => {

module.exports = require("@aws-sdk/client-dynamodb");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.deleteSlot = exports.createSlot = exports.getSlots = void 0;
const uuid_1 = __webpack_require__(903);
const dynamodb_1 = __webpack_require__(334);
const middleware_1 = __webpack_require__(342);
const getSlots = async (event) => {
    try {
        const authResult = (0, middleware_1.requireAuth)(event);
        if ('error' in authResult) {
            return authResult.error;
        }
        const { date, available } = event.queryStringParameters || {};
        let slots;
        if (date) {
            slots = await (0, dynamodb_1.dbQuery)(dynamodb_1.SLOTS_TABLE, 'DateIndex', '#date = :date', { ':date': date });
        }
        else if (available === 'true') {
            slots = await (0, dynamodb_1.dbQuery)(dynamodb_1.SLOTS_TABLE, 'BookingStatusIndex', 'isBooked = :isBooked', { ':isBooked': 'false' });
        }
        else {
            slots = await (0, dynamodb_1.dbScan)(dynamodb_1.SLOTS_TABLE);
        }
        const { user } = authResult;
        if (user.role !== 'owner') {
            const now = new Date();
            slots = slots.filter((slot) => {
                const slotDateTime = new Date(`${slot.date}T${slot.time}`);
                return slotDateTime > now;
            });
        }
        slots.sort((a, b) => {
            const dateCompare = a.date.localeCompare(b.date);
            if (dateCompare !== 0)
                return dateCompare;
            return a.time.localeCompare(b.time);
        });
        return {
            statusCode: 200,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify(slots)
        };
    }
    catch (error) {
        console.error('Get slots error:', error);
        return {
            statusCode: 500,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify({ error: 'Failed to fetch slots' })
        };
    }
};
exports.getSlots = getSlots;
const createSlot = async (event) => {
    try {
        const authResult = (0, middleware_1.requireOwner)(event);
        if ('error' in authResult) {
            return authResult.error;
        }
        if (!event.body) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Request body is required' })
            };
        }
        const { date, time, duration = 60 } = JSON.parse(event.body);
        if (!date || !time) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Date and time are required' })
            };
        }
        if (![30, 60].includes(duration)) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Duration must be 30 or 60 minutes' })
            };
        }
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Date must be in YYYY-MM-DD format' })
            };
        }
        if (!/^\d{2}:\d{2}$/.test(time)) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Time must be in HH:MM format' })
            };
        }
        const existingSlots = await (0, dynamodb_1.dbQuery)(dynamodb_1.SLOTS_TABLE, 'DateIndex', '#date = :date', { ':date': date });
        const slotExists = existingSlots.some((slot) => slot.time === time && slot.duration === duration);
        if (slotExists) {
            return {
                statusCode: 409,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Slot already exists for this date and time' })
            };
        }
        const slotId = (0, uuid_1.v4)();
        const slot = {
            id: slotId,
            date,
            time,
            duration,
            isBooked: 'false',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        await (0, dynamodb_1.dbPut)(dynamodb_1.SLOTS_TABLE, slot);
        return {
            statusCode: 201,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify(slot)
        };
    }
    catch (error) {
        console.error('Create slot error:', error);
        return {
            statusCode: 500,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify({ error: 'Failed to create slot' })
        };
    }
};
exports.createSlot = createSlot;
const deleteSlot = async (event) => {
    try {
        const authResult = (0, middleware_1.requireOwner)(event);
        if ('error' in authResult) {
            return authResult.error;
        }
        const slotId = event.pathParameters?.id;
        if (!slotId) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Slot ID is required' })
            };
        }
        const slot = await (0, dynamodb_1.dbGet)(dynamodb_1.SLOTS_TABLE, { id: slotId });
        if (!slot) {
            return {
                statusCode: 404,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Slot not found' })
            };
        }
        if (slot.isBooked === 'true') {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Cannot delete booked slot' })
            };
        }
        await (0, dynamodb_1.dbDelete)(dynamodb_1.SLOTS_TABLE, { id: slotId });
        return {
            statusCode: 200,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify({ message: 'Slot deleted successfully' })
        };
    }
    catch (error) {
        console.error('Delete slot error:', error);
        return {
            statusCode: 500,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify({ error: 'Failed to delete slot' })
        };
    }
};
exports.deleteSlot = deleteSlot;

})();

module.exports = __webpack_exports__;
/******/ })()
;