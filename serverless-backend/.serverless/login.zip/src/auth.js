/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 334:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.dbQuery = exports.dbScan = exports.dbDelete = exports.dbUpdate = exports.dbPut = exports.dbGet = exports.SLOTS_TABLE = exports.CLASSES_TABLE = exports.BOOKINGS_TABLE = exports.USERS_TABLE = exports.dynamodb = void 0;
const client_dynamodb_1 = __webpack_require__(929);
const lib_dynamodb_1 = __webpack_require__(515);
const client = new client_dynamodb_1.DynamoDBClient({ region: 'us-east-1' });
exports.dynamodb = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
exports.USERS_TABLE = process.env.USERS_TABLE;
exports.BOOKINGS_TABLE = process.env.BOOKINGS_TABLE;
exports.CLASSES_TABLE = process.env.CLASSES_TABLE;
exports.SLOTS_TABLE = process.env.SLOTS_TABLE;
const dbGet = async (tableName, key) => {
    const command = new lib_dynamodb_1.GetCommand({
        TableName: tableName,
        Key: key
    });
    const response = await exports.dynamodb.send(command);
    return response.Item;
};
exports.dbGet = dbGet;
const dbPut = async (tableName, item) => {
    const command = new lib_dynamodb_1.PutCommand({
        TableName: tableName,
        Item: item
    });
    return await exports.dynamodb.send(command);
};
exports.dbPut = dbPut;
const dbUpdate = async (tableName, key, updateExpression, expressionAttributeValues, expressionAttributeNames) => {
    const command = new lib_dynamodb_1.UpdateCommand({
        TableName: tableName,
        Key: key,
        UpdateExpression: updateExpression,
        ExpressionAttributeValues: expressionAttributeValues,
        ExpressionAttributeNames: expressionAttributeNames,
        ReturnValues: 'ALL_NEW'
    });
    const response = await exports.dynamodb.send(command);
    return response.Attributes;
};
exports.dbUpdate = dbUpdate;
const dbDelete = async (tableName, key) => {
    const command = new lib_dynamodb_1.DeleteCommand({
        TableName: tableName,
        Key: key
    });
    return await exports.dynamodb.send(command);
};
exports.dbDelete = dbDelete;
const dbScan = async (tableName, filterExpression, expressionAttributeValues) => {
    const command = new lib_dynamodb_1.ScanCommand({
        TableName: tableName,
        FilterExpression: filterExpression,
        ExpressionAttributeValues: expressionAttributeValues
    });
    const response = await exports.dynamodb.send(command);
    return response.Items || [];
};
exports.dbScan = dbScan;
const dbQuery = async (tableName, indexName, keyConditionExpression, expressionAttributeValues) => {
    const command = new lib_dynamodb_1.QueryCommand({
        TableName: tableName,
        IndexName: indexName,
        KeyConditionExpression: keyConditionExpression,
        ExpressionAttributeValues: expressionAttributeValues
    });
    const response = await exports.dynamodb.send(command);
    return response.Items || [];
};
exports.dbQuery = dbQuery;


/***/ }),

/***/ 515:
/***/ ((module) => {

module.exports = require("@aws-sdk/lib-dynamodb");

/***/ }),

/***/ 688:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.register = exports.login = void 0;
const bcrypt = __importStar(__webpack_require__(729));
const jwt = __importStar(__webpack_require__(829));
const uuid_1 = __webpack_require__(903);
const dynamodb_1 = __webpack_require__(334);
const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret';
const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
};
const login = async (event) => {
    try {
        if (!event.body) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({ error: 'Request body is required' })
            };
        }
        const { email, password } = JSON.parse(event.body);
        if (!email || !password) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({ error: 'Email and password are required' })
            };
        }
        const users = await (0, dynamodb_1.dbQuery)(dynamodb_1.USERS_TABLE, 'EmailIndex', 'email = :email', { ':email': email });
        if (users.length === 0) {
            return {
                statusCode: 401,
                headers,
                body: JSON.stringify({ error: 'Invalid credentials' })
            };
        }
        const user = users[0];
        const isValidPassword = await bcrypt.compare(password, user.passwordHash);
        if (!isValidPassword) {
            return {
                statusCode: 401,
                headers,
                body: JSON.stringify({ error: 'Invalid credentials' })
            };
        }
        const token = jwt.sign({
            userId: user.id,
            email: user.email,
            role: user.role
        }, JWT_SECRET, { expiresIn: '24h' });
        const { passwordHash, ...userData } = user;
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                message: 'Login successful',
                user: userData,
                token
            })
        };
    }
    catch (error) {
        console.error('Login error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: 'Internal server error' })
        };
    }
};
exports.login = login;
const register = async (event) => {
    try {
        if (!event.body) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({ error: 'Request body is required' })
            };
        }
        const { email, password, name, dogName } = JSON.parse(event.body);
        if (!email || !password || !name) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({ error: 'Email, password, and name are required' })
            };
        }
        const existingUsers = await (0, dynamodb_1.dbQuery)(dynamodb_1.USERS_TABLE, 'EmailIndex', 'email = :email', { ':email': email });
        if (existingUsers.length > 0) {
            return {
                statusCode: 409,
                headers,
                body: JSON.stringify({ error: 'User already exists' })
            };
        }
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);
        const userId = (0, uuid_1.v4)();
        const user = {
            id: userId,
            email,
            name,
            role: 'customer',
            dogName: dogName || null,
            passwordHash: hashedPassword,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        await (0, dynamodb_1.dbPut)(dynamodb_1.USERS_TABLE, user);
        const token = jwt.sign({
            userId: user.id,
            email: user.email,
            role: user.role
        }, JWT_SECRET, { expiresIn: '24h' });
        const { passwordHash: _, ...userData } = user;
        return {
            statusCode: 201,
            headers,
            body: JSON.stringify({
                message: 'Registration successful',
                user: userData,
                token
            })
        };
    }
    catch (error) {
        console.error('Registration error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: 'Internal server error' })
        };
    }
};
exports.register = register;


/***/ }),

/***/ 729:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 829:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 903:
/***/ ((module) => {

module.exports = require("uuid");

/***/ }),

/***/ 929:
/***/ ((module) => {

module.exports = require("@aws-sdk/client-dynamodb");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(688);
/******/ 	module.exports = __webpack_exports__;
/******/ 	
/******/ })()
;