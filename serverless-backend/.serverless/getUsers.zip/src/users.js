/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 334:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.dbQuery = exports.dbScan = exports.dbDelete = exports.dbUpdate = exports.dbPut = exports.dbGet = exports.SLOTS_TABLE = exports.CLASSES_TABLE = exports.BOOKINGS_TABLE = exports.USERS_TABLE = exports.dynamodb = void 0;
const client_dynamodb_1 = __webpack_require__(929);
const lib_dynamodb_1 = __webpack_require__(515);
const client = new client_dynamodb_1.DynamoDBClient({ region: 'us-east-1' });
exports.dynamodb = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
exports.USERS_TABLE = process.env.USERS_TABLE;
exports.BOOKINGS_TABLE = process.env.BOOKINGS_TABLE;
exports.CLASSES_TABLE = process.env.CLASSES_TABLE;
exports.SLOTS_TABLE = process.env.SLOTS_TABLE;
const dbGet = async (tableName, key) => {
    const command = new lib_dynamodb_1.GetCommand({
        TableName: tableName,
        Key: key
    });
    const response = await exports.dynamodb.send(command);
    return response.Item;
};
exports.dbGet = dbGet;
const dbPut = async (tableName, item) => {
    const command = new lib_dynamodb_1.PutCommand({
        TableName: tableName,
        Item: item
    });
    return await exports.dynamodb.send(command);
};
exports.dbPut = dbPut;
const dbUpdate = async (tableName, key, updateExpression, expressionAttributeValues, expressionAttributeNames) => {
    const command = new lib_dynamodb_1.UpdateCommand({
        TableName: tableName,
        Key: key,
        UpdateExpression: updateExpression,
        ExpressionAttributeValues: expressionAttributeValues,
        ExpressionAttributeNames: expressionAttributeNames,
        ReturnValues: 'ALL_NEW'
    });
    const response = await exports.dynamodb.send(command);
    return response.Attributes;
};
exports.dbUpdate = dbUpdate;
const dbDelete = async (tableName, key) => {
    const command = new lib_dynamodb_1.DeleteCommand({
        TableName: tableName,
        Key: key
    });
    return await exports.dynamodb.send(command);
};
exports.dbDelete = dbDelete;
const dbScan = async (tableName, filterExpression, expressionAttributeValues) => {
    const command = new lib_dynamodb_1.ScanCommand({
        TableName: tableName,
        FilterExpression: filterExpression,
        ExpressionAttributeValues: expressionAttributeValues
    });
    const response = await exports.dynamodb.send(command);
    return response.Items || [];
};
exports.dbScan = dbScan;
const dbQuery = async (tableName, indexName, keyConditionExpression, expressionAttributeValues) => {
    const command = new lib_dynamodb_1.QueryCommand({
        TableName: tableName,
        IndexName: indexName,
        KeyConditionExpression: keyConditionExpression,
        ExpressionAttributeValues: expressionAttributeValues
    });
    const response = await exports.dynamodb.send(command);
    return response.Items || [];
};
exports.dbQuery = dbQuery;


/***/ }),

/***/ 342:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.responseHeaders = exports.requireOwner = exports.requireAuth = exports.authenticate = void 0;
const jwt = __importStar(__webpack_require__(829));
const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret';
const authenticate = (event) => {
    try {
        const authHeader = event.headers.Authorization || event.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return null;
        }
        const token = authHeader.substring(7);
        const decoded = jwt.verify(token, JWT_SECRET);
        return {
            userId: decoded.userId,
            email: decoded.email,
            role: decoded.role
        };
    }
    catch (error) {
        console.error('Authentication error:', error);
        return null;
    }
};
exports.authenticate = authenticate;
const requireAuth = (event) => {
    const user = (0, exports.authenticate)(event);
    if (!user) {
        return {
            error: {
                statusCode: 401,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
                },
                body: JSON.stringify({ error: 'Unauthorized' })
            }
        };
    }
    return { user };
};
exports.requireAuth = requireAuth;
const requireOwner = (event) => {
    const authResult = (0, exports.requireAuth)(event);
    if ('error' in authResult) {
        return authResult;
    }
    if (authResult.user.role !== 'owner') {
        return {
            error: {
                statusCode: 403,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
                },
                body: JSON.stringify({ error: 'Forbidden: Owner access required' })
            }
        };
    }
    return authResult;
};
exports.requireOwner = requireOwner;
exports.responseHeaders = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
};


/***/ }),

/***/ 515:
/***/ ((module) => {

module.exports = require("@aws-sdk/lib-dynamodb");

/***/ }),

/***/ 729:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 756:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.updateUser = exports.getUser = exports.getUsers = void 0;
const bcrypt = __importStar(__webpack_require__(729));
const dynamodb_1 = __webpack_require__(334);
const middleware_1 = __webpack_require__(342);
const getUsers = async (event) => {
    try {
        const authResult = (0, middleware_1.requireOwner)(event);
        if ('error' in authResult) {
            return authResult.error;
        }
        const { role } = event.queryStringParameters || {};
        let users;
        if (role) {
            users = await (0, dynamodb_1.dbQuery)(dynamodb_1.USERS_TABLE, 'RoleIndex', '#role = :role', { ':role': role });
        }
        else {
            users = await (0, dynamodb_1.dbScan)(dynamodb_1.USERS_TABLE);
        }
        const sanitizedUsers = users.map((user) => {
            const { passwordHash, ...userWithoutPassword } = user;
            return userWithoutPassword;
        });
        sanitizedUsers.sort((a, b) => a.name.localeCompare(b.name));
        return {
            statusCode: 200,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify(sanitizedUsers)
        };
    }
    catch (error) {
        console.error('Get users error:', error);
        return {
            statusCode: 500,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify({ error: 'Failed to fetch users' })
        };
    }
};
exports.getUsers = getUsers;
const getUser = async (event) => {
    try {
        const authResult = (0, middleware_1.requireAuth)(event);
        if ('error' in authResult) {
            return authResult.error;
        }
        const { user: currentUser } = authResult;
        const userId = event.pathParameters?.id;
        if (!userId) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'User ID is required' })
            };
        }
        if (currentUser.role !== 'owner' && currentUser.userId !== userId) {
            return {
                statusCode: 403,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Forbidden' })
            };
        }
        const user = await (0, dynamodb_1.dbGet)(dynamodb_1.USERS_TABLE, { id: userId });
        if (!user) {
            return {
                statusCode: 404,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'User not found' })
            };
        }
        const { passwordHash, ...userWithoutPassword } = user;
        return {
            statusCode: 200,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify(userWithoutPassword)
        };
    }
    catch (error) {
        console.error('Get user error:', error);
        return {
            statusCode: 500,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify({ error: 'Failed to fetch user' })
        };
    }
};
exports.getUser = getUser;
const updateUser = async (event) => {
    try {
        const authResult = (0, middleware_1.requireAuth)(event);
        if ('error' in authResult) {
            return authResult.error;
        }
        const { user: currentUser } = authResult;
        const userId = event.pathParameters?.id;
        if (!userId) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'User ID is required' })
            };
        }
        if (!event.body) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Request body is required' })
            };
        }
        if (currentUser.role !== 'owner' && currentUser.userId !== userId) {
            return {
                statusCode: 403,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Forbidden' })
            };
        }
        const updates = JSON.parse(event.body);
        const existingUser = await (0, dynamodb_1.dbGet)(dynamodb_1.USERS_TABLE, { id: userId });
        if (!existingUser) {
            return {
                statusCode: 404,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'User not found' })
            };
        }
        const updateExpressions = [];
        const expressionAttributeValues = {
            ':updatedAt': new Date().toISOString()
        };
        const expressionAttributeNames = {};
        if (updates.name !== undefined) {
            if (!updates.name.trim()) {
                return {
                    statusCode: 400,
                    headers: middleware_1.responseHeaders,
                    body: JSON.stringify({ error: 'Name cannot be empty' })
                };
            }
            updateExpressions.push('#name = :name');
            expressionAttributeNames['#name'] = 'name';
            expressionAttributeValues[':name'] = updates.name.trim();
        }
        if (updates.dogName !== undefined) {
            updateExpressions.push('dogName = :dogName');
            expressionAttributeValues[':dogName'] = updates.dogName ? updates.dogName.trim() : null;
        }
        if (updates.email !== undefined) {
            const emailCheck = await (0, dynamodb_1.dbQuery)(dynamodb_1.USERS_TABLE, 'EmailIndex', 'email = :email', { ':email': updates.email });
            if (emailCheck.length > 0 && emailCheck[0].id !== userId) {
                return {
                    statusCode: 409,
                    headers: middleware_1.responseHeaders,
                    body: JSON.stringify({ error: 'Email already in use' })
                };
            }
            updateExpressions.push('email = :email');
            expressionAttributeValues[':email'] = updates.email.trim().toLowerCase();
        }
        if (updates.password !== undefined) {
            if (updates.password.length < 6) {
                return {
                    statusCode: 400,
                    headers: middleware_1.responseHeaders,
                    body: JSON.stringify({ error: 'Password must be at least 6 characters' })
                };
            }
            const saltRounds = 10;
            const passwordHash = await bcrypt.hash(updates.password, saltRounds);
            updateExpressions.push('passwordHash = :passwordHash');
            expressionAttributeValues[':passwordHash'] = passwordHash;
        }
        if (updates.role !== undefined && currentUser.role === 'owner') {
            const validRoles = ['owner', 'customer'];
            if (!validRoles.includes(updates.role)) {
                return {
                    statusCode: 400,
                    headers: middleware_1.responseHeaders,
                    body: JSON.stringify({ error: 'Invalid role' })
                };
            }
            updateExpressions.push('#role = :role');
            expressionAttributeNames['#role'] = 'role';
            expressionAttributeValues[':role'] = updates.role;
        }
        if (updateExpressions.length === 0) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'No valid fields to update' })
            };
        }
        updateExpressions.push('updatedAt = :updatedAt');
        const updateExpression = `SET ${updateExpressions.join(', ')}`;
        const updatedUser = await (0, dynamodb_1.dbUpdate)(dynamodb_1.USERS_TABLE, { id: userId }, updateExpression, expressionAttributeValues, Object.keys(expressionAttributeNames).length > 0 ? expressionAttributeNames : undefined);
        const { passwordHash: _, ...userWithoutPassword } = updatedUser;
        return {
            statusCode: 200,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify(userWithoutPassword)
        };
    }
    catch (error) {
        console.error('Update user error:', error);
        return {
            statusCode: 500,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify({ error: 'Failed to update user' })
        };
    }
};
exports.updateUser = updateUser;


/***/ }),

/***/ 829:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 929:
/***/ ((module) => {

module.exports = require("@aws-sdk/client-dynamodb");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(756);
/******/ 	module.exports = __webpack_exports__;
/******/ 	
/******/ })()
;