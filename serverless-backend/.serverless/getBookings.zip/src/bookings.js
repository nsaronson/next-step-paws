/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 334:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.dbQuery = exports.dbScan = exports.dbDelete = exports.dbUpdate = exports.dbPut = exports.dbGet = exports.SLOTS_TABLE = exports.CLASSES_TABLE = exports.BOOKINGS_TABLE = exports.USERS_TABLE = exports.dynamodb = void 0;
const client_dynamodb_1 = __webpack_require__(929);
const lib_dynamodb_1 = __webpack_require__(515);
const client = new client_dynamodb_1.DynamoDBClient({ region: 'us-east-1' });
exports.dynamodb = lib_dynamodb_1.DynamoDBDocumentClient.from(client);
exports.USERS_TABLE = process.env.USERS_TABLE;
exports.BOOKINGS_TABLE = process.env.BOOKINGS_TABLE;
exports.CLASSES_TABLE = process.env.CLASSES_TABLE;
exports.SLOTS_TABLE = process.env.SLOTS_TABLE;
const dbGet = async (tableName, key) => {
    const command = new lib_dynamodb_1.GetCommand({
        TableName: tableName,
        Key: key
    });
    const response = await exports.dynamodb.send(command);
    return response.Item;
};
exports.dbGet = dbGet;
const dbPut = async (tableName, item) => {
    const command = new lib_dynamodb_1.PutCommand({
        TableName: tableName,
        Item: item
    });
    return await exports.dynamodb.send(command);
};
exports.dbPut = dbPut;
const dbUpdate = async (tableName, key, updateExpression, expressionAttributeValues, expressionAttributeNames) => {
    const command = new lib_dynamodb_1.UpdateCommand({
        TableName: tableName,
        Key: key,
        UpdateExpression: updateExpression,
        ExpressionAttributeValues: expressionAttributeValues,
        ExpressionAttributeNames: expressionAttributeNames,
        ReturnValues: 'ALL_NEW'
    });
    const response = await exports.dynamodb.send(command);
    return response.Attributes;
};
exports.dbUpdate = dbUpdate;
const dbDelete = async (tableName, key) => {
    const command = new lib_dynamodb_1.DeleteCommand({
        TableName: tableName,
        Key: key
    });
    return await exports.dynamodb.send(command);
};
exports.dbDelete = dbDelete;
const dbScan = async (tableName, filterExpression, expressionAttributeValues) => {
    const command = new lib_dynamodb_1.ScanCommand({
        TableName: tableName,
        FilterExpression: filterExpression,
        ExpressionAttributeValues: expressionAttributeValues
    });
    const response = await exports.dynamodb.send(command);
    return response.Items || [];
};
exports.dbScan = dbScan;
const dbQuery = async (tableName, indexName, keyConditionExpression, expressionAttributeValues) => {
    const command = new lib_dynamodb_1.QueryCommand({
        TableName: tableName,
        IndexName: indexName,
        KeyConditionExpression: keyConditionExpression,
        ExpressionAttributeValues: expressionAttributeValues
    });
    const response = await exports.dynamodb.send(command);
    return response.Items || [];
};
exports.dbQuery = dbQuery;


/***/ }),

/***/ 342:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.responseHeaders = exports.requireOwner = exports.requireAuth = exports.authenticate = void 0;
const jwt = __importStar(__webpack_require__(829));
const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret';
const authenticate = (event) => {
    try {
        const authHeader = event.headers.Authorization || event.headers.authorization;
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return null;
        }
        const token = authHeader.substring(7);
        const decoded = jwt.verify(token, JWT_SECRET);
        return {
            userId: decoded.userId,
            email: decoded.email,
            role: decoded.role
        };
    }
    catch (error) {
        console.error('Authentication error:', error);
        return null;
    }
};
exports.authenticate = authenticate;
const requireAuth = (event) => {
    const user = (0, exports.authenticate)(event);
    if (!user) {
        return {
            error: {
                statusCode: 401,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
                },
                body: JSON.stringify({ error: 'Unauthorized' })
            }
        };
    }
    return { user };
};
exports.requireAuth = requireAuth;
const requireOwner = (event) => {
    const authResult = (0, exports.requireAuth)(event);
    if ('error' in authResult) {
        return authResult;
    }
    if (authResult.user.role !== 'owner') {
        return {
            error: {
                statusCode: 403,
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
                    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
                },
                body: JSON.stringify({ error: 'Forbidden: Owner access required' })
            }
        };
    }
    return authResult;
};
exports.requireOwner = requireOwner;
exports.responseHeaders = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
};


/***/ }),

/***/ 515:
/***/ ((module) => {

module.exports = require("@aws-sdk/lib-dynamodb");

/***/ }),

/***/ 829:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 903:
/***/ ((module) => {

module.exports = require("uuid");

/***/ }),

/***/ 929:
/***/ ((module) => {

module.exports = require("@aws-sdk/client-dynamodb");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.deleteBooking = exports.updateBooking = exports.createBooking = exports.getBookings = void 0;
const uuid_1 = __webpack_require__(903);
const dynamodb_1 = __webpack_require__(334);
const middleware_1 = __webpack_require__(342);
const getBookings = async (event) => {
    try {
        const authResult = (0, middleware_1.requireAuth)(event);
        if ('error' in authResult) {
            return authResult.error;
        }
        const { user } = authResult;
        let bookings;
        if (user.role === 'owner') {
            bookings = await (0, dynamodb_1.dbScan)(dynamodb_1.BOOKINGS_TABLE);
        }
        else {
            bookings = await (0, dynamodb_1.dbQuery)(dynamodb_1.BOOKINGS_TABLE, 'UserIndex', 'userId = :userId', { ':userId': user.userId });
        }
        const enhancedBookings = await Promise.all(bookings.map(async (booking) => {
            const slot = await (0, dynamodb_1.dbGet)(dynamodb_1.SLOTS_TABLE, { id: booking.slotId });
            return {
                ...booking,
                slot: slot || null
            };
        }));
        return {
            statusCode: 200,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify(enhancedBookings)
        };
    }
    catch (error) {
        console.error('Get bookings error:', error);
        return {
            statusCode: 500,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify({ error: 'Failed to fetch bookings' })
        };
    }
};
exports.getBookings = getBookings;
const createBooking = async (event) => {
    try {
        const authResult = (0, middleware_1.requireAuth)(event);
        if ('error' in authResult) {
            return authResult.error;
        }
        const { user } = authResult;
        if (!event.body) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Request body is required' })
            };
        }
        const { slotId, dogName, notes } = JSON.parse(event.body);
        if (!slotId || !dogName) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Slot ID and dog name are required' })
            };
        }
        const slot = await (0, dynamodb_1.dbGet)(dynamodb_1.SLOTS_TABLE, { id: slotId });
        if (!slot) {
            return {
                statusCode: 404,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Time slot not found' })
            };
        }
        if (slot.isBooked === 'true') {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Time slot not available' })
            };
        }
        const slotDateTime = new Date(`${slot.date}T${slot.time}`);
        if (slotDateTime <= new Date()) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Cannot book past time slots' })
            };
        }
        const bookingId = (0, uuid_1.v4)();
        const booking = {
            id: bookingId,
            slotId,
            userId: user.userId,
            dogName: dogName.trim(),
            notes: notes || null,
            status: 'confirmed',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        await (0, dynamodb_1.dbPut)(dynamodb_1.BOOKINGS_TABLE, booking);
        await (0, dynamodb_1.dbUpdate)(dynamodb_1.SLOTS_TABLE, { id: slotId }, 'SET isBooked = :isBooked, updatedAt = :updatedAt', {
            ':isBooked': 'true',
            ':updatedAt': new Date().toISOString()
        });
        return {
            statusCode: 201,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify({
                ...booking,
                slot
            })
        };
    }
    catch (error) {
        console.error('Create booking error:', error);
        return {
            statusCode: 500,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify({ error: 'Failed to create booking' })
        };
    }
};
exports.createBooking = createBooking;
const updateBooking = async (event) => {
    try {
        const authResult = (0, middleware_1.requireAuth)(event);
        if ('error' in authResult) {
            return authResult.error;
        }
        const { user } = authResult;
        const bookingId = event.pathParameters?.id;
        if (!bookingId) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Booking ID is required' })
            };
        }
        if (!event.body) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Request body is required' })
            };
        }
        const { dogName, notes, status } = JSON.parse(event.body);
        const existingBooking = await (0, dynamodb_1.dbGet)(dynamodb_1.BOOKINGS_TABLE, { id: bookingId });
        if (!existingBooking) {
            return {
                statusCode: 404,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Booking not found' })
            };
        }
        if (user.role !== 'owner' && existingBooking.userId !== user.userId) {
            return {
                statusCode: 403,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Forbidden' })
            };
        }
        const updateExpressions = [];
        const expressionAttributeValues = {
            ':updatedAt': new Date().toISOString()
        };
        if (dogName !== undefined) {
            updateExpressions.push('dogName = :dogName');
            expressionAttributeValues[':dogName'] = dogName.trim();
        }
        if (notes !== undefined) {
            updateExpressions.push('notes = :notes');
            expressionAttributeValues[':notes'] = notes || null;
        }
        if (status !== undefined) {
            const validStatuses = ['confirmed', 'pending', 'cancelled'];
            if (!validStatuses.includes(status)) {
                return {
                    statusCode: 400,
                    headers: middleware_1.responseHeaders,
                    body: JSON.stringify({ error: 'Invalid status' })
                };
            }
            updateExpressions.push('#status = :status');
            expressionAttributeValues[':status'] = status;
        }
        updateExpressions.push('updatedAt = :updatedAt');
        const updateExpression = `SET ${updateExpressions.join(', ')}`;
        const expressionAttributeNames = status !== undefined ? { '#status': 'status' } : undefined;
        if (status === 'cancelled' && existingBooking.status !== 'cancelled') {
            await (0, dynamodb_1.dbUpdate)(dynamodb_1.SLOTS_TABLE, { id: existingBooking.slotId }, 'SET isBooked = :isBooked, updatedAt = :updatedAt', {
                ':isBooked': 'false',
                ':updatedAt': new Date().toISOString()
            });
        }
        const updatedBooking = await (0, dynamodb_1.dbUpdate)(dynamodb_1.BOOKINGS_TABLE, { id: bookingId }, updateExpression, expressionAttributeValues, expressionAttributeNames);
        return {
            statusCode: 200,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify(updatedBooking)
        };
    }
    catch (error) {
        console.error('Update booking error:', error);
        return {
            statusCode: 500,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify({ error: 'Failed to update booking' })
        };
    }
};
exports.updateBooking = updateBooking;
const deleteBooking = async (event) => {
    try {
        const authResult = (0, middleware_1.requireAuth)(event);
        if ('error' in authResult) {
            return authResult.error;
        }
        const { user } = authResult;
        const bookingId = event.pathParameters?.id;
        if (!bookingId) {
            return {
                statusCode: 400,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Booking ID is required' })
            };
        }
        const existingBooking = await (0, dynamodb_1.dbGet)(dynamodb_1.BOOKINGS_TABLE, { id: bookingId });
        if (!existingBooking) {
            return {
                statusCode: 404,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Booking not found' })
            };
        }
        if (user.role !== 'owner' && existingBooking.userId !== user.userId) {
            return {
                statusCode: 403,
                headers: middleware_1.responseHeaders,
                body: JSON.stringify({ error: 'Forbidden' })
            };
        }
        await (0, dynamodb_1.dbDelete)(dynamodb_1.BOOKINGS_TABLE, { id: bookingId });
        await (0, dynamodb_1.dbUpdate)(dynamodb_1.SLOTS_TABLE, { id: existingBooking.slotId }, 'SET isBooked = :isBooked, updatedAt = :updatedAt', {
            ':isBooked': false,
            ':updatedAt': new Date().toISOString()
        });
        return {
            statusCode: 200,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify({ message: 'Booking cancelled successfully' })
        };
    }
    catch (error) {
        console.error('Delete booking error:', error);
        return {
            statusCode: 500,
            headers: middleware_1.responseHeaders,
            body: JSON.stringify({ error: 'Failed to cancel booking' })
        };
    }
};
exports.deleteBooking = deleteBooking;

})();

module.exports = __webpack_exports__;
/******/ })()
;